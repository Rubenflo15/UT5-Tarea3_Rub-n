window.onload=function(){

    //Llamamos a la función obtenerhora con 500 milisegundos(medio segundo).Estoes lo que permite que el reloj se actualice.
    let t=setInterval(obtenerhora,500);
}

function obtenerhora(){

    let fecha = new Date();// Creamos un objeto de tipo fecha
    //Extraemos la hora de la variable donde hemos guardado la fecha

    let h=fecha.getHours();
    //Si la hora no tiene dos digitos, le añadiremos un cero delante
    if(h<10) {
        h="0"+h;
    }

    //Extraemos los minutos de la variable donde hemos guardado la fecha
    let m=fecha.getMinutes();
    //Si los minutos no tienen dos digitos, le añadiremos un cero delante
    if(m<10) {
        m="0"+m;
    }
    //Extraemos los segundos de la variable donde hemos guardado la fecha
    let s=fecha.getSeconds();
    //Si los segundos no tienen dos digitos, le añadiremos un cero deltane

    if(s<10){
        s="0"+s;
    }
    document.getElementById("reloj").innerHTML=h+":"+m+":"+s;
}