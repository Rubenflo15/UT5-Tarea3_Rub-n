window.onload=function(){

    let btn = document.getElementById("boton");

    btn.addEventListener('click',mover);

}


function mover (){
    let elem =document.getElementById("animar");
    let pos =0;
    let id = setInterval(frame, 100);//Son milisegundos(5), Cambiamos la velocidad( de 5 a 100) milisegundos

    function frame(){
        if(pos==150){ // Si cambiamos el pos podemos hacer que la distancia sea más corta o más lenta cambie de (350 a 150).
            clearInterval(id);//Detiene el bucle cronometrado
        }
        else{
        pos++;
       // elem.style.top = pos + 'px'; Si quitamos este elemstyle el cuadrado se movera solo horizontalmente.
        elem.style.left = pos + 'px';
    }
    }
}